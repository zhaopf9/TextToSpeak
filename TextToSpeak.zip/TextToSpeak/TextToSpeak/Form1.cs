﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Speech.Synthesis;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextToSpeak
{
    public partial class Form1 : Form
    {
        private SpeechSynthesizer ss;
        protected override void OnLoad(EventArgs e)
        {
            ss = new SpeechSynthesizer();
        }

        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 播放按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
                int rate = trackBar2.Value;
                int volume = trackBar1.Value;
                string text = textBox1.Text;//获取要播放的文本
                //开启线程
                Task.Run(() =>
                {
                    ss.Rate =rate ;//语速
                    ss.Volume = volume;//获取设置音量
                    ss.Speak(text);
                });
                
            
        }

        /// <summary>
        /// 清空文本框
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 代开文件夹
        /// </summary>
        /// <returns></returns>
        private OpenFileDialog OpenFile()
        {
            //定义一个文件打开控件
            OpenFileDialog ofd = new OpenFileDialog();
            //设置打开对话框的初始目录，默认目录为exe运行文件所在的路径
            //ofd.InitialDirectory = Application.StartupPath;
            //设置打开对话框的标题
            ofd.Title = "请选择要打开的文件";
            //设置打开对话框可以多选
            ofd.Multiselect = true;
            //设置对话框打开的文件类型
            ofd.Filter = "文本文件|*.txt|所有文件|*.*";
            //设置文件对话框当前选定的筛选器的索引
            ofd.FilterIndex = 2;
            //设置对话框是否记忆之前打开的目录
            ofd.RestoreDirectory = true;

            return ofd;
        }

        /// <summary>
        /// 读取文本文件内容
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            //定义一个文件打开控件
            OpenFileDialog ofd = OpenFile();

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                //获取用户选择的文件完整路径
                string filePath = ofd.FileName;

                try
                {
                    // 创建一个 StreamReader 的实例来读取文件 
                    // using 语句也能关闭 StreamReader
                    using (StreamReader sr = new StreamReader(filePath))
                    {
                        string line;
                        string lines="";

                        // 从文件读取并显示行，直到文件的末尾 
                        while ((line = sr.ReadLine()) != null)
                        {
                            lines += line.Replace(" ", "");
                             
                        }
                        //赋值给文本
                        textBox1.Text = lines;
                    }
                }
                catch (Exception e1)
                {
                    // 向用户显示出错消息
                    textBox1.Text = "文件不符合规定，请打开文本文件（.txt）"+e1.Message;
                }

                
            }
        }

        /// <summary>
        /// 保存输入框内容
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            //定义一个文件保存控件
            SaveFileDialog pSaveFileDialog = new SaveFileDialog()
            {
                Title = "保存为:",
                RestoreDirectory = true,
                Filter = "文本文件|*.txt",
                FileName="草稿文件"//默认名字
            };//同打开文件，也可指定任意类型的文件
            if (pSaveFileDialog.ShowDialog() == DialogResult.OK)
            {
                // 创建文件，准备写入
                using(FileStream fs = File.Open(pSaveFileDialog.FileName,FileMode.Create,FileAccess.Write))
                {
                    StreamWriter wr = new StreamWriter(fs);

                    // 逐行将textBox1的内容写入到文件中
                    foreach (string line in textBox1.Lines)
                    {
                        wr.WriteLine(line);
                    }

                    // 关闭文件
                    wr.Flush();
                    wr.Close();
                    fs.Close();
                }
                MessageBox.Show("保存成功！", "提示");
            }

            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (button5.Text == "暂停")
            {
                button5.Text = "继续";
                ss.Pause();
            }
            else if (button5.Text == "继续")
            {
                button5.Text = "暂停";
                ss.Resume();
            }
        }
    }
}
